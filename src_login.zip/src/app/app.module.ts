
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { EmployeeCreateComponent } from './employee-create/employee-create.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';




//import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
//import {MatSidenavModule} from '@angular/material'

//import { MatMenuModule, MatButtonModule, MatIconModule, MatCardModule } from '@angular/material';



import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { JailComponent } from './jail/jail.component';
import { QuerymanagementComponent } from './querymanagement/querymanagement.component';
import { LogoutComponent } from './logout/logout.component';
import { ThinkComponent } from './think/think.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NavComponent } from './nav/nav.component';
import { LayoutModule } from '@angular/cdk/layout';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';

@NgModule({
  declarations: [
    AppComponent,
    EmployeeCreateComponent,
    EmployeeListComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    LoginComponent,
    JailComponent,
    QuerymanagementComponent,
    LogoutComponent,
    ThinkComponent,
    NavComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,

    FormsModule,

    BrowserAnimationsModule,

    LayoutModule,

    MatToolbarModule,

    MatButtonModule,

    MatSidenavModule,

    MatIconModule,

    MatListModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }


