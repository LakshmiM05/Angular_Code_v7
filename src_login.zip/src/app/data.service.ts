
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  employees = [
    {id: 1, name: "ABC", location: "Chennai", email: "em001@email.com"},
    {id: 2, name: "XYZ", location: "Delhi", email: "em002@email.com"},
    {id: 3, name: "TUV", location: "Bangalore", email: "em003@email.com"},
    {id: 4, name: "EFG", location: "Mumbai", email: "em004@email.com"}
  ];

  constructor() { }

  public getEmployees():Array<{id, name, location, email}>{
    return this.employees;
  }
  public createEmployee(employee: {id, name, location, email}){
    this.employees.push(employee);
  }
}




