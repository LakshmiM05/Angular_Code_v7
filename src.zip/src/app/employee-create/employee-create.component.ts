import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-employee-create',
  templateUrl: './employee-create.component.html',
  styleUrls: ['./employee-create.component.css']
})
export class EmployeeCreateComponent implements OnInit {

  employee : {id, name, location, email} = {id: null, name: "", location: "", email: ""};

  constructor(public dataService: DataService) { }


    ngOnInit() {
  }


  createContact(){
    console.log(this.employee);
    this.dataService.createEmployee(this.employee);
    this.employee = {id: null, name: "", location: "", email: ""};

  }

}
