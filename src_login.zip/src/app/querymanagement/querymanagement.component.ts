import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-querymanagement',
  templateUrl: './querymanagement.component.html',
  styleUrls: ['./querymanagement.component.css']
})
export class QuerymanagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
