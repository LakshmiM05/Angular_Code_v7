import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-jail',
  templateUrl: './jail.component.html',
  styleUrls: ['./jail.component.css']
})
export class JailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
