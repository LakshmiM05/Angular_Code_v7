import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { EmployeeCreateComponent } from './employee-create/employee-create.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LogoutComponent } from './logout/logout.component';
import { JailComponent } from './jail/jail.component';
import { QuerymanagementComponent } from './querymanagement/querymanagement.component';
import { ThinkComponent } from './think/think.component';


const routes: Routes = [
  {path: "", pathMatch: "full",redirectTo: "login"},
  {path: "home", component: HomeComponent},
  {path: "employee-create", component: EmployeeCreateComponent},
  {path: "employee-list", component: EmployeeListComponent},
  { path: 'login', component: LoginComponent },
  { path: 'logout', component: LogoutComponent },
  { path: 'querymgmt', component: QuerymanagementComponent },
  { path: 'think', component: ThinkComponent },
  { path: 'jails', component: JailComponent },

  
  //{path: "jails-main", component: JailMainComponent}  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
